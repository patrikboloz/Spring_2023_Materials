// Exercises: Classes
// Exercise 1

#include <iostream>
using namespace std;

class rectangle {

   public:
   int x,y;
   int area(){return x*y;}

};
